'use strict';

(() => {
    console.log('test');
})();
